import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'reader_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> _recent = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final list = (prefs.getStringList('recent') ?? [])
        .where((f) => File(f).existsSync())
        .toList();
    if (mounted) setState(() => _recent = list);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('recent', _recent);
  }

  Future<void> _pick() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    final src = res?.files.single.path;
    if (src == null) return;
    setState(() => _busy = true);
    try {
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory(p.join(docs.path, 'pdfs'))
        ..createSync(recursive: true);
      final dest = p.join(dir.path, p.basename(src));
      await File(src).copy(dest);
      _recent.remove(dest);
      _recent.insert(0, dest);
      if (_recent.length > 20) _recent = _recent.sublist(0, 20);
      await _save();
      if (mounted) await _open(dest);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Could not open file: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _open(String path) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ReaderPage(path: path)),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final red = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: AppBar(title: const Text('Red Lookup')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _pick,
        icon: const Icon(Icons.folder_open),
        label: const Text('Open PDF'),
      ),
      body: _busy
          ? const Center(child: CircularProgressIndicator())
          : _recent.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.menu_book, size: 96, color: red),
                        const SizedBox(height: 16),
                        Text('Open a PDF, then tap any word\nto see its meaning.',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.titleMedium),
                      ],
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.only(bottom: 96),
                  itemCount: _recent.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final path = _recent[i];
                    return Dismissible(
                      key: ValueKey(path),
                      background: Container(color: red),
                      onDismissed: (_) {
                        setState(() => _recent.removeAt(i));
                        _save();
                      },
                      child: ListTile(
                        leading: Icon(Icons.picture_as_pdf, color: red, size: 36),
                        title: Text(p.basenameWithoutExtension(path)),
                        subtitle: const Text('Swipe to remove from list'),
                        onTap: () => _open(path),
                      ),
                    );
                  },
                ),
    );
  }
}
