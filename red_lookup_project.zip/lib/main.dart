import 'package:flutter/material.dart';

import 'home_page.dart';

const Color kRed = Color(0xFFC62828);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RedLookupApp());
}

class RedLookupApp extends StatelessWidget {
  const RedLookupApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: kRed).copyWith(
      primary: kRed,
      onPrimary: Colors.white,
    );
    return MaterialApp(
      title: 'Red Lookup',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        appBarTheme: const AppBarTheme(
          backgroundColor: kRed,
          foregroundColor: Colors.white,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: kRed,
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomePage(),
    );
  }
}
