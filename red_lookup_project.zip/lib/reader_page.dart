import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dictionary.dart';
import 'main.dart' show kRed;

/// One word on a PDF page, with the rectangles of its characters.
class WordBox {
  WordBox(this.text, this.chars) {
    var l = double.infinity, b = double.infinity;
    var r = -double.infinity, t = -double.infinity;
    for (final c in chars) {
      l = math.min(l, c.left);
      r = math.max(r, c.right);
      b = math.min(b, c.bottom);
      t = math.max(t, c.top);
    }
    left = l;
    right = r;
    bottom = b;
    top = t;
  }

  final String text;
  final List<PdfRect> chars;
  late final double left, right, top, bottom; // PDF page coordinates

  /// Distance from a point to this word. Vertical distance counts double so a
  /// tap between two lines prefers the word on the same line.
  double distanceTo(double x, double y) {
    final dx = math.max(math.max(left - x, x - right), 0.0);
    final dy = math.max(math.max(bottom - y, y - top), 0.0);
    return math.sqrt(dx * dx + 4 * dy * dy);
  }
}

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key, required this.path});
  final String path;

  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  final PdfViewerController _controller = PdfViewerController();
  PdfDocument? _doc;
  final Map<int, List<WordBox>> _words = {};

  int _page = 1;
  int _pageCount = 1;

  int? _selPage;
  int? _selIdx;
  LookupResult? _result;
  bool _loading = false;

  // How far (in PDF points) a tap may be from a word and still pick it.
  static const double _maxTapDistance = 40;

  String get _prefsKey => 'page:${widget.path}';

  WordBox? get _selected {
    if (_selPage == null || _selIdx == null) return null;
    final list = _words[_selPage!];
    if (list == null || _selIdx! >= list.length) return null;
    return list[_selIdx!];
  }

  // ---------- text extraction ----------

  static bool _isLetter(String ch) => RegExp(r'\p{L}', unicode: true).hasMatch(ch);
  static bool _isApostrophe(String ch) => ch == "'" || ch == '\u2019';

  Future<List<WordBox>> _wordsForPage(PdfPage page) async {
    final cached = _words[page.pageNumber];
    if (cached != null) return cached;

    final PdfPageText? text = await page.loadText();
    final result = <WordBox>[];
    if (text != null) {
      final full = text.fullText;
      final rects = text.charRects;
      final n = math.min(full.length, rects.length);
      var i = 0;
      while (i < n) {
        if (!_isLetter(full[i])) {
          i++;
          continue;
        }
        var j = i;
        while (j < n &&
            (_isLetter(full[j]) ||
                (_isApostrophe(full[j]) && j + 1 < n && _isLetter(full[j + 1])))) {
          j++;
        }
        result.add(WordBox(full.substring(i, j), rects.sublist(i, j)));
        i = j;
      }
    }
    _words[page.pageNumber] = result;
    return result;
  }

  Future<List<WordBox>> _wordsForNumber(int pageNumber) async {
    final doc = _doc;
    if (doc == null) return [];
    return _wordsForPage(doc.pages[pageNumber - 1]);
  }

  // ---------- selecting words ----------

  bool _onGeneralTap(BuildContext context, PdfViewerController controller,
      PdfViewerGeneralTapHandlerDetails details) {
    if (details.type == PdfViewerGeneralTapType.tap ||
        details.type == PdfViewerGeneralTapType.longPress) {
      final hit = controller.getPdfPageHitTestResult(
        details.documentPosition,
        useDocumentLayoutCoordinates: true,
      );
      if (hit != null) {
        _selectAt(hit.page, hit.offset.x, hit.offset.y);
        return true;
      }
    }
    return false;
  }

  Future<void> _selectAt(PdfPage page, double x, double y) async {
    final words = await _wordsForPage(page);
    if (words.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No selectable text on this page (it may be a scanned image).'),
        ));
      }
      return;
    }
    var best = -1;
    var bestDist = double.infinity;
    for (var i = 0; i < words.length; i++) {
      final d = words[i].distanceTo(x, y);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    }
    if (best < 0 || bestDist > _maxTapDistance) return;
    await _select(page.pageNumber, best);
  }

  Future<void> _select(int pageNumber, int index) async {
    final list = _words[pageNumber];
    if (list == null) return;
    setState(() {
      _selPage = pageNumber;
      _selIdx = index;
      _loading = true;
    });
    _controller.invalidate();
    final word = list[index].text;
    final r = await Dictionary.instance.lookup(word);
    if (!mounted || _selPage != pageNumber || _selIdx != index) return;
    setState(() {
      _result = r;
      _loading = false;
    });
  }

  Future<void> _step(int delta) async {
    if (_selPage == null || _selIdx == null) return;
    var pn = _selPage!;
    var idx = _selIdx! + delta;
    var list = await _wordsForNumber(pn);
    while (idx < 0 || idx >= list.length) {
      pn += delta;
      if (pn < 1 || pn > _pageCount) return;
      list = await _wordsForNumber(pn);
      idx = delta > 0 ? 0 : list.length - 1;
      if (list.isNotEmpty) _controller.goToPage(pageNumber: pn);
    }
    await _select(pn, idx);
  }

  void _clearSelection() {
    setState(() {
      _selPage = null;
      _selIdx = null;
      _result = null;
      _loading = false;
    });
    _controller.invalidate();
  }

  // ---------- painting the red highlight ----------

  void _paintHighlight(ui.Canvas canvas, Rect pageRect, PdfPage page) {
    final word = _selected;
    if (word == null || _selPage != page.pageNumber) return;
    Rect? box;
    for (final c in word.chars) {
      final r = c
          .toRect(page: page, scaledPageSize: pageRect.size)
          .translate(pageRect.left, pageRect.top);
      box = box == null ? r : box.expandToInclude(r);
    }
    if (box == null) return;
    final rr = RRect.fromRectAndRadius(box.inflate(2), const Radius.circular(4));
    canvas.drawRRect(rr, Paint()..color = const Color(0x55E53935));
    canvas.drawRRect(
      rr,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = kRed,
    );
  }

  // ---------- pages ----------

  Future<void> _onViewerReady(PdfDocument doc, PdfViewerController c) async {
    _doc = doc;
    final prefs = await SharedPreferences.getInstance();
    final last = prefs.getInt(_prefsKey) ?? 1;
    if (!mounted) return;
    setState(() => _pageCount = doc.pages.length);
    if (last > 1 && last <= doc.pages.length) {
      _controller.goToPage(pageNumber: last);
    }
  }

  Future<void> _onPageChanged(int? n) async {
    if (n == null) return;
    setState(() => _page = n);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefsKey, n);
  }

  Future<void> _askPage() async {
    final ctl = TextEditingController(text: '$_page');
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Go to page'),
        content: TextField(
          controller: ctl,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(hintText: '1 - $_pageCount'),
          onSubmitted: (v) => Navigator.pop(ctx, int.tryParse(v)),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(ctl.text)),
            child: const Text('Go'),
          ),
        ],
      ),
    );
    if (n != null) {
      _controller.goToPage(pageNumber: n.clamp(1, _pageCount));
    }
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basenameWithoutExtension(widget.path),
            overflow: TextOverflow.ellipsis),
      ),
      body: LayoutBuilder(builder: (context, box) {
        final wide = box.maxWidth > 800;
        final viewer = _buildViewer();
        if (wide) {
          // Tablet landscape: meaning panel sits on the right, page never jumps.
          return Row(
            children: [
              Expanded(
                child: Column(children: [
                  Expanded(child: viewer),
                  _pageBar(),
                ]),
              ),
              SizedBox(width: 380, child: _panel(box.maxHeight, sideBySide: true)),
            ],
          );
        }
        // Portrait: panel slides over the bottom part of the page.
        return Column(children: [
          Expanded(
            child: Stack(children: [
              Positioned.fill(child: viewer),
              if (_selPage != null)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: _panel(box.maxHeight, sideBySide: false),
                ),
            ]),
          ),
          _pageBar(),
        ]);
      }),
    );
  }

  Widget _buildViewer() {
    return PdfViewer.file(
      widget.path,
      controller: _controller,
      params: PdfViewerParams(
        backgroundColor: const Color(0xFFEEEEEE),
        onViewerReady: _onViewerReady,
        onPageChanged: _onPageChanged,
        onGeneralTap: _onGeneralTap,
        pagePaintCallbacks: [_paintHighlight],
        viewerOverlayBuilder: (context, size, handleLinkTap) => [
          PdfViewerScrollThumb(
            controller: _controller,
            orientation: ScrollbarOrientation.right,
            thumbSize: const Size(56, 32),
            thumbBuilder: (context, thumbSize, pageNumber, controller) => Container(
              decoration: BoxDecoration(
                color: kRed,
                borderRadius: BorderRadius.circular(8),
              ),
              alignment: Alignment.center,
              child: Text('${pageNumber ?? ''}',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _pageBar() {
    return Material(
      elevation: 8,
      color: Colors.white,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            IconButton(
              icon: const Icon(Icons.chevron_left),
              onPressed:
                  _page > 1 ? () => _controller.goToPage(pageNumber: _page - 1) : null,
            ),
            Expanded(
              child: _pageCount > 1
                  ? Slider(
                      min: 1,
                      max: _pageCount.toDouble(),
                      value: _page.clamp(1, _pageCount).toDouble(),
                      onChanged: (v) => _controller.goToPage(pageNumber: v.round()),
                    )
                  : const SizedBox.shrink(),
            ),
            TextButton(
              onPressed: _askPage,
              child: Text('$_page / $_pageCount',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: _page < _pageCount
                  ? () => _controller.goToPage(pageNumber: _page + 1)
                  : null,
            ),
          ]),
        ),
      ),
    );
  }

  Widget _panel(double availableHeight, {required bool sideBySide}) {
    final word = _selected;
    final header = Row(children: [
      Expanded(
        child: Text(
          word?.text ?? 'Tap a word',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: word == null ? Colors.black45 : kRed,
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ),
      IconButton(
        tooltip: 'Previous word',
        iconSize: 32,
        color: kRed,
        icon: const Icon(Icons.chevron_left),
        onPressed: word == null ? null : () => _step(-1),
      ),
      IconButton(
        tooltip: 'Next word',
        iconSize: 32,
        color: kRed,
        icon: const Icon(Icons.chevron_right),
        onPressed: word == null ? null : () => _step(1),
      ),
      if (word != null)
        IconButton(
          tooltip: 'Close',
          icon: const Icon(Icons.close),
          onPressed: _clearSelection,
        ),
    ]);

    final body = Expanded(child: _meaning(word));

    final content = Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [header, const Divider(height: 8), body],
      ),
    );

    return Material(
      elevation: 16,
      color: Colors.white,
      shape: sideBySide
          ? null
          : const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              side: BorderSide(color: kRed, width: 2),
            ),
      child: sideBySide
          ? SafeArea(child: content)
          : SizedBox(height: math.min(340, availableHeight * 0.42), child: content),
    );
  }

  Widget _meaning(WordBox? word) {
    if (word == null) {
      return const Center(
        child: Text(
          'Tap near any word in the PDF.\nIf it picks a neighbour, use the arrows.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54, fontSize: 16),
        ),
      );
    }
    if (_loading) {
      return const Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(top: 24),
          child: CircularProgressIndicator(color: kRed),
        ),
      );
    }
    final r = _result;
    if (r == null) {
      return Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Text(
          'No entry found for \u201c${word.text}\u201d.\n'
          'It may be a name or a rare word. Use the arrows to try a neighbouring word.',
          style: const TextStyle(fontSize: 16),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.only(right: 8, bottom: 16),
      children: [
        for (final e in r.entries) ...[
          if (e.lemma != r.query)
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 4),
              child: Text('form of \u201c${e.lemma}\u201d',
                  style: const TextStyle(
                      fontSize: 15,
                      color: kRed,
                      fontWeight: FontWeight.w600)),
            ),
          ..._senseWidgets(e),
        ],
      ],
    );
  }

  List<Widget> _senseWidgets(Entry e) {
    final widgets = <Widget>[];
    String? lastPos;
    var n = 0;
    for (final s in e.senses) {
      if (s.pos != lastPos) {
        lastPos = s.pos;
        n = 0;
        widgets.add(Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 2),
          child: Text(s.posLabel,
              style: const TextStyle(
                  fontStyle: FontStyle.italic,
                  fontSize: 15,
                  color: Colors.black54)),
        ));
      }
      n++;
      widgets.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$n. ${s.definition}', style: const TextStyle(fontSize: 18)),
            for (final ex in s.examples.take(2))
              Padding(
                padding: const EdgeInsets.only(left: 18, top: 2),
                child: Text('\u201c$ex\u201d',
                    style: const TextStyle(
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                        color: Colors.black54)),
              ),
          ],
        ),
      ));
    }
    return widgets;
  }
}
