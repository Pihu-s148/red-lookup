import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class Sense {
  Sense(this.pos, this.definition, this.examples);
  final String pos; // n, v, a, r
  final String definition;
  final List<String> examples;

  String get posLabel => const {
        'n': 'noun',
        'v': 'verb',
        'a': 'adjective',
        'r': 'adverb',
      }[pos]!;
}

class Entry {
  Entry(this.lemma, this.senses);
  final String lemma;
  final List<Sense> senses;
}

class LookupResult {
  LookupResult(this.query, this.entries);
  final String query;
  final List<Entry> entries;
}

/// Offline WordNet lookup with simple word-form handling
/// ("running" -> "run", "studies" -> "study", "geese" -> "goose").
class Dictionary {
  Dictionary._();
  static final Dictionary instance = Dictionary._();

  Database? _db;

  Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir = await getApplicationSupportDirectory();
    final path = p.join(dir.path, 'wordnet_v1.db');
    if (!File(path).existsSync()) {
      final data = await rootBundle.load('assets/wordnet.db');
      await File(path).writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        flush: true,
      );
    }
    _db = await openDatabase(path, readOnly: true);
    return _db!;
  }

  static const _rules = <List<String>>[
    ['s', ''],
    ['ses', 's'],
    ['xes', 'x'],
    ['zes', 'z'],
    ['ches', 'ch'],
    ['shes', 'sh'],
    ['men', 'man'],
    ['ies', 'y'],
    ['es', 'e'],
    ['es', ''],
    ['ed', 'e'],
    ['ed', ''],
    ['ied', 'y'],
    ['ing', 'e'],
    ['ing', ''],
    ['er', ''],
    ['er', 'e'],
    ['ier', 'y'],
    ['est', ''],
    ['est', 'e'],
    ['iest', 'y'],
  ];

  Future<List<String>> _candidates(Database db, String w) async {
    final out = <String>[w];
    final exc = await db.query('exc', where: 'inflected = ?', whereArgs: [w]);
    for (final r in exc) {
      out.add(r['base'] as String);
    }
    for (final rule in _rules) {
      final suffix = rule[0], repl = rule[1];
      if (w.length > suffix.length + 1 && w.endsWith(suffix)) {
        final stem = w.substring(0, w.length - suffix.length) + repl;
        out.add(stem);
        // running -> runn -> run
        if (stem.length >= 3 &&
            stem[stem.length - 1] == stem[stem.length - 2] &&
            !'aeiou'.contains(stem[stem.length - 1])) {
          out.add(stem.substring(0, stem.length - 1));
        }
      }
    }
    final seen = <String>{};
    return out.where(seen.add).toList();
  }

  Future<LookupResult?> lookup(String raw) async {
    final db = await _open();
    var w = raw.toLowerCase().replaceAll('\u2019', "'").trim();
    w = w.replaceAll(RegExp(r"'s$"), '').replaceAll(RegExp(r"^'+|'+$"), '');
    if (w.isEmpty) return null;

    final entries = <Entry>[];
    for (final c in await _candidates(db, w)) {
      final rows = await db.query('senses',
          where: 'lemma = ?', whereArgs: [c], orderBy: 'rowid');
      if (rows.isEmpty) continue;
      final senses = rows.map((r) {
        final ex = (r['examples'] as String?) ?? '';
        return Sense(
          r['pos'] as String,
          r['definition'] as String,
          ex.isEmpty ? <String>[] : ex.split('\n'),
        );
      }).toList();
      entries.add(Entry(c, senses));
      if (entries.length >= 3) break;
    }
    if (entries.isEmpty) return null;
    return LookupResult(w, entries);
  }
}
