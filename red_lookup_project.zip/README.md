# Red Lookup

A red-themed Android PDF reader with an offline dictionary (Princeton WordNet 3.0).
Open a PDF, tap any word, and its meaning appears.

## Get the APK (no coding tools needed)
1. Create a new repository on github.com and upload everything in this folder
   (including the hidden `.github` folder - drag and drop the folder contents).
2. Open the **Actions** tab -> **Build APK** -> **Run workflow** (it also runs on every push).
3. When it finishes (about 5-8 minutes), open the run and download **RedLookup-apk** at the bottom.
4. Unzip it, copy `app-release.apk` to your tablet and open it
   (allow "Install unknown apps" when asked).

## Using the app
- **Open PDF** copies the file into the app and remembers it in your recent list.
- Scroll normally, drag the red page handle on the right edge, use the slider,
  or tap the "12 / 240" label to type a page number.
- **Tap near a word**: the nearest word is highlighted in red and defined.
  If the wrong neighbour was picked, use the red arrows in the panel.
- On a wide tablet screen the meaning panel is on the right; in portrait it slides up from the bottom.

## Licences
WordNet 3.0 (c) Princeton University - https://wordnet.princeton.edu/license-and-commercial-use
