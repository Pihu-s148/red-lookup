#!/usr/bin/env python3
"""Builds assets/wordnet.db from Princeton WordNet 3.0.

Usage:
  python tools/build_dictionary.py            # downloads WordNet 3.0
  python tools/build_dictionary.py path/dict  # use an already-extracted 'dict' folder
"""
import io
import os
import re
import sqlite3
import sys
import tarfile
import urllib.request

URL = "https://wordnetcode.princeton.edu/3.0/WNdb-3.0.tar.gz"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "wordnet.db")
POS = [("n", "noun"), ("v", "verb"), ("a", "adj"), ("r", "adv")]


def make_reader(local_dir):
    if local_dir:
        def read(name):
            with open(os.path.join(local_dir, name), encoding="utf-8") as f:
                return f.read()
        return read
    print("Downloading WordNet 3.0 ...")
    raw = urllib.request.urlopen(URL, timeout=120).read()
    tar = tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz")
    files = {}
    for m in tar.getmembers():
        if m.isfile():
            files[os.path.basename(m.name)] = tar.extractfile(m).read().decode("utf-8")

    def read(name):
        if name not in files:
            raise FileNotFoundError(name)
        return files[name]
    return read


def parse_data(text):
    """offset -> (definition, [examples])"""
    out = {}
    for line in text.splitlines():
        if not line or line.startswith("  "):
            continue
        left, _, gloss = line.partition(" | ")
        offset = left.split(" ", 1)[0]
        definition = re.split(r';\s*"', gloss, maxsplit=1)[0].strip().rstrip(";")
        examples = re.findall(r'"([^"]+)"', gloss)
        out[offset] = (definition, examples)
    return out


def main():
    local = sys.argv[1] if len(sys.argv) > 1 else None
    read = make_reader(local)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    if os.path.exists(OUT):
        os.remove(OUT)
    db = sqlite3.connect(OUT)
    db.execute("CREATE TABLE senses (lemma TEXT, pos TEXT, n INTEGER, definition TEXT, examples TEXT)")
    db.execute("CREATE TABLE exc (inflected TEXT, base TEXT, pos TEXT)")
    count = 0
    for code, fname in POS:
        data = parse_data(read("data." + fname))
        for line in read("index." + fname).splitlines():
            if not line or line.startswith("  "):
                continue
            parts = line.split()
            lemma = parts[0].replace("_", " ").lower()
            synset_cnt = int(parts[2])
            offsets = parts[-synset_cnt:]
            for n, off in enumerate(offsets, 1):
                if off not in data:
                    continue
                d, ex = data[off]
                db.execute("INSERT INTO senses VALUES (?,?,?,?,?)", (lemma, code, n, d, "\n".join(ex)))
                count += 1
        try:
            for line in read(fname + ".exc").splitlines():
                p = line.split()
                for base in p[1:]:
                    db.execute("INSERT INTO exc VALUES (?,?,?)",
                               (p[0].replace("_", " ").lower(), base.replace("_", " ").lower(), code))
        except FileNotFoundError:
            pass
    db.execute("CREATE INDEX idx_senses_lemma ON senses(lemma)")
    db.execute("CREATE INDEX idx_exc ON exc(inflected)")
    db.commit()
    db.execute("VACUUM")
    db.close()
    print("Done: %d senses -> %s (%.1f MB)" % (count, os.path.abspath(OUT), os.path.getsize(OUT) / 1e6))


if __name__ == "__main__":
    main()
